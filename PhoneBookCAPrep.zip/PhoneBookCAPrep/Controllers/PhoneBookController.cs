﻿using PhoneBookCAPrep.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace PhoneBookCAPrep.Controllers
{
    /*
    * GET /api/phonebook/number     get entry for number
    * GET /api/phonebook?name=      get entries for name
    */

    [RoutePrefix("phonebook")]
    public class PhoneBookController : ApiController
    {
        //static List<PhoneBookEntry> phoneBook; // List of phone book entries
        private static List<PhoneBookEntry> phoneBook = new List<PhoneBookEntry>()      // List of phone book entries
        {
            new PhoneBookEntry() {Number = "01 1111111", Name =  "John Doe", Address = "1 Bev Hills"},
            new PhoneBookEntry() {Number = "01 2222222", Name =  "Jane Doe", Address = "2 Bev Hills"},
            new PhoneBookEntry() {Number = "01 3333333", Name =  "Joe Soap", Address = "3 Bev Hills"}
        };


        // Populate list in memory
        public PhoneBookController()
        {
            //phoneBook = new List<PhoneBookEntry>();
            //phoneBook.Add(new PhoneBookEntry() {Number = "01 1111111", Name = "John Doe", Address = "No 1 Bev Hills"});
            //phoneBook.Add(new PhoneBookEntry() {Number = "01 2222222", Name = "Jane Doe", Address = "No 2 Bev Hills"});
            //phoneBook.Add(new PhoneBookEntry() {Number = "01 3333333", Name = "Joe Soap", Address = "No 3 Bev Hills"});

            // This should really be done in persistent storage
        }

        [Route("number/{number}")]
        // GET phonebook/number/01 1111111
        public IHttpActionResult GetEntry(String number)
        {
            // LINQ Query, find matching entries for number
            var entries = phoneBook.FirstOrDefault(e => e.Number.ToUpper() == number.ToUpper());
            if (entries == null)
            {
                return NotFound();
            }
            return Ok(entries);
        }

        [Route("name/{name}")]
        // GET phonebook/name/Jane Doe
        public IHttpActionResult GetEntriesForName(String name)
        {
            // LINQ Query, find matching entries for name
            var entries = phoneBook.Where(n => n.Name.ToUpper() == name.ToUpper());
            if (entries == null)
            {
                return NotFound();
            }
            return Ok(entries);
        }


        // POST api/phonebook
        // Add an entry to phonebook
        public IHttpActionResult PostAddEntry(PhoneBookEntry entry)
        {
            if (ModelState.IsValid) // model class validation ok?
            {
                // check for duplicate number
                var record = phoneBook.Find(p => p.Number == entry.Number);
                if (record == null)
                {
                    phoneBook.Add(entry);
                    return Ok();
                }
                else
                {
                    return NotFound();
                }
            }
            else
            {
                return BadRequest();
            }
        }

        // GET ../api/phonebook
        // Return all entries in phonebook
        public IEnumerable<PhoneBookEntry> GetAllPhoneBookEntries()
        {
            return phoneBook;
        }

        // PUT 
        // Update a number for an entry
        //[Route("phonebook/number/{number}")]
        public void PutUpdateNumberForEntry(String number, PhoneBookEntry phonebookentry)
        {
            if (ModelState.IsValid)
            {
                if (number == phonebookentry.Number)
                {
                    int index = phoneBook.FindIndex(a => a.Number == phonebookentry.Number);
                    if (index == -1)
                    {
                        throw new HttpResponseException(HttpStatusCode.NotFound);
                    }
                    else
                    {
                        phoneBook.RemoveAt(index);
                        phoneBook.Add(phonebookentry);
                    }
                }
                else
                {
                    throw new HttpResponseException(HttpStatusCode.BadRequest);
                }
            }
            else
            {
                throw new HttpResponseException(HttpStatusCode.BadRequest);
            }
        }


        // DELETE ../api/phonebook/number
        // Delete an entry from the phonebook
        [Route("number/{number}")]
        public void DeleteEntry(String number)
        {
            var record = phoneBook.Find(a => a.Number.ToUpper() == number);
            if (record != null)
            {
                phoneBook.Remove(record);
            }
            else
            {
                throw new HttpResponseException(HttpStatusCode.BadRequest);
            }

        }

    }
}
