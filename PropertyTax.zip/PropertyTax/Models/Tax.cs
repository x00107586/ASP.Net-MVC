﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyTax.Models
{
    public struct Bands
    {
        public const double Band1 = 50000;
        public const double Band2 = 125000;
        public const double Band3 = 175000;
        public const double Band4 = 225000;
        public const double Band5 = 275000;
        public const double Band6 = 325000;
        public const double Band7 = 375000;
        public const double Band8 = 425000;
        public const double Band9 = 475000;
    }

    public class Tax
    {
        [Required(ErrorMessage = "Required field")]
        [Display(Name = "Property Band")]
        public Bands Band { get; set; }

        [Required(ErrorMessage = "Required field")]
        [Display(Name = "Property Value")]
        public double PropertyVal { get; set; }

        [Display(Name = "Property Tax")]
        public double Cost
        {
            get
            {
                double tax = 0.0;
                if(PropertyVal <= 100000)
                {
                    tax = (Bands.Band1 / 100) * 0.18;
                }
                else if(PropertyVal > 100000 && PropertyVal <= 150000)
                {
                    tax = (Bands.Band2 / 100) * 0.18;
                }
                else if (PropertyVal > 150000 && PropertyVal <= 200000)
                {
                    tax = (Bands.Band3 / 100) * 0.18;
                }
                else if (PropertyVal > 200000 && PropertyVal <= 250000)
                {
                    tax = (Bands.Band4 / 100) * 0.18;
                }
                else if (PropertyVal > 250000 && PropertyVal <= 300000)
                {
                    tax = (Bands.Band5 / 100) * 0.18;
                }
                else if (PropertyVal > 300000 && PropertyVal <= 350000)
                {
                    tax = (Bands.Band6 / 100) * 0.18;
                }
                else if (PropertyVal > 350000 && PropertyVal <= 400000)
                {
                    tax = (Bands.Band7 / 100) * 0.18;
                }
                else if (PropertyVal > 400000 && PropertyVal <= 450000)
                {
                    tax = (Bands.Band8 / 100) * 0.18;
                }
                else if (PropertyVal > 450000 && PropertyVal <= 500000)
                {
                    tax = (Bands.Band9 / 100) * 0.18;
                }
                return tax;
            }
        }
    }
}
