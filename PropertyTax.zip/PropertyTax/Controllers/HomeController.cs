﻿using PropertyTax.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PropertyTax.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Calculate()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Calculate(Tax t)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("Confirm", t);
            }
            else
            {
                return View(t);
            }
        }

        public ActionResult Confirm(Tax t)
        {
            return View(t);
        }
    }
}