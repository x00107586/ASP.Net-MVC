﻿// Michael Smith x00107586
// URL of website: http://eadca3x00107586.azurewebsites.net/

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EADCA3.Models
{
    // Enum for different vehicle types
    public enum VehicleCategory
    {
        [Display(Name = "Car")]
        Car,
        [Display(Name = "Public Service Vehicle")]
        PublicServiceVehicle,
        [Display(Name = "Bus")]
        Bus,
        [Display(Name = "Goods")]
        Goods
    }

    public class TollCharge
    {
        // Prices for Vehicles
        // Reading prices in from the web.config file and storing them in the variable
        public double CarCharge = Double.Parse(System.Configuration.ConfigurationManager.AppSettings["CarToll"]);
        public double PSVCharge = Double.Parse(System.Configuration.ConfigurationManager.AppSettings["PSVToll"]);
        public double BusCharge = Double.Parse(System.Configuration.ConfigurationManager.AppSettings["BusToll"]);
        public double GoodsCharge = Double.Parse(System.Configuration.ConfigurationManager.AppSettings["GoodsToll"]);

        // Vehicle category 
        [Display(Name = "Vehicle Category")]
        public VehicleCategory Vehicle { get; set; }

        // Find out whether the vehicle has an electronic tag or not
        [Display(Name = "Does your vehicle have an electronic tag? (Leave blank for No)")]
        public bool ElectronicTag { get; set; }

        // Total Charge with or without discount
        [Display(Name = "Total Charge(€)")]
        public double TotalCharge
        {
            get
            {
                double discount = 0.0;
                if(ElectronicTag == true)
                {
                    // Discount of 20% if the vehicle has an electronic tag
                    discount = 20.0 * (VehicleCharge / 100);
                }
                else
                {
                    // No discount if no electronic tag
                    discount = 0.0;
                }
                return VehicleCharge - discount;
            }
        }

        // Calculate the toll charge for each vehicle type
        [Display(Name = "Toll Charge")]
        public double VehicleCharge
        {
            get
            {
                double charge = 0.0;
                if(Vehicle == VehicleCategory.Car)
                {
                    charge = CarCharge;
                }
                else if (Vehicle == VehicleCategory.PublicServiceVehicle)
                {
                    charge = PSVCharge;
                }
                else if(Vehicle == VehicleCategory.Bus)
                {
                    charge = BusCharge;
                }
                else if (Vehicle == VehicleCategory.Goods)
                {

                    charge = GoodsCharge;
                }
                return charge;
            }
        }
    }
}
