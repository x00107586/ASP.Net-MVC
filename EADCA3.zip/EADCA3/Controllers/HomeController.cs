﻿// Michael Smith x00107586
// URL of website: http://eadca3x00107586.azurewebsites.net/

using EADCA3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EADCA3.Controllers
{
    public class HomeController : Controller
    {
        // GET:
        [HttpGet]
        public ActionResult Calculate()
        {
            return View();
        }

        // Return 1 view only

        // POST:
        [HttpPost]
        public ActionResult Calculate(TollCharge tc)
        {
            return View(tc);
        }
    }
}