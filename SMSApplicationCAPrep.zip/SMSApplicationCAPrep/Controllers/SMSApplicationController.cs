﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;


using SMSApplicationCAPrep.Models;

namespace SMSApplicationCAPrep.Controllers
{
    public class SMSApplicationController : ApiController
    {
        private const int MaxSize = 140;
        private const String LOGFILENAME = "C:\\Users\\Michael\\Documents\\College\\Semester 8\\EAD 2\\LogFile.txt";

        // POST /api/SMSAPPlication/
        public IHttpActionResult PostSendSMS(TextMessage message)
        {
            if (ModelState.IsValid)
            {
                // Log to file
                log("Sent: " + message.Content + " from " + message.FromNumber + " to " + message.ToNumber);
                return Ok();
            }
            else
            {
                return BadRequest();
            }
        }

        // Log to file, may need to run VS as administrator in order to have access to the file system
        [NonAction]
        private void log(String logInfo)
        {
            using (StreamWriter stream = File.AppendText(LOGFILENAME))
            {
                stream.Write(logInfo);
                stream.WriteLine(" " + DateTime.Now);
                stream.Close();
            }
        }
    }
}
