﻿using PhoneBookCAPrep.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBookClientCAPrep
{
    class Program
    {
        static async Task DoWork()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:49342/");

                    // Accept JSON
                    client.DefaultRequestHeaders.
                        Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));


                    // GET ../phonebook/name/John Doe
                    // Return the address and number of the contact named John Doe
                    HttpResponseMessage response = await client.GetAsync("phonebook/name/John Doe");
                    if (response.IsSuccessStatusCode)
                    {
                        // Read result
                        var entries = await response.Content.ReadAsAsync<IEnumerable<PhoneBookEntry>>();    // Returns an object of specific type and store the entries in a variable entries
                        foreach (var entry in entries)  // Loop through each entry
                        {
                            Console.WriteLine(entry.Address + " " + entry.Number);  // Print the address and number
                        }
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase);   // Return an error status code to the console
                    }

                    // GET ../phonebook/number/01 3333333
                    // Return the details of the user whos phone number is 01 3333333 
                    response = await client.GetAsync("phonebook/number/01 3333333");    // GetAsync sends a get request to the Url for the info
                    if (response.IsSuccessStatusCode)   // If successful
                    {
                        // Read result
                        var result = await response.Content.ReadAsAsync<PhoneBookEntry>();  // Store results from a returned object of specific type
                        Console.WriteLine(result.Name + " " + result.Address);      // Write the resulting name and address
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase);       // Return error code
                    }


                    // POST /api/phonebook with an entry serialised in request body
                    // create a new entry
                    PhoneBookEntry newEntry1 = new PhoneBookEntry()  // Create a new PhoneBookEntry object
                    {
                        Number = "01 4444444",
                        Name = "Michael Smith",
                        Address = "4 Bev Hills"
                    };
                    response = await client.PostAsJsonAsync("api/phonebook", newEntry1);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Updated");
                        //var newResult = await response1.Content.ReadAsAsync<PhoneBookEntry>();
                        //Console.WriteLine(newResult.Number + " " + newResult.Name + " " + newResult.Address + " ");
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase + "  ERROR");
                    }



                    

                    // Return all entries in phonebook
                    // GET ../api/phonebook
                    response = await client.GetAsync("api/phonebook");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsAsync<IEnumerable<PhoneBookEntry>>();
                        foreach (var i in result)
                        {
                            Console.WriteLine(i.Number + " " + i.Name + " " + i.Address);
                        }
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase);
                    }


                    // POST /api/phonebook with an entry serialised in request body
                    // create a new entry
                    PhoneBookEntry newEntry = new PhoneBookEntry()  // Create a new PhoneBookEntry object
                    {
                        Number = "01 5555555",
                        Name = "Adam Flood",
                        Address = "5 Bev Hills"
                    };
                    response = await client.PostAsJsonAsync("api/phonebook", newEntry);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Updated");
                        //var newResult = await response1.Content.ReadAsAsync<PhoneBookEntry>();
                        //Console.WriteLine(newResult.Number + " " + newResult.Name + " " + newResult.Address + " ");
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase + "  ERROR");
                    }


                    // Return all entries in phonebook
                    // GET ../api/phonebook
                    response = await client.GetAsync("api/phonebook");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsAsync<IEnumerable<PhoneBookEntry>>();
                        foreach (var i in result)
                        {
                            Console.WriteLine(i.Number + " " + i.Name + " " + i.Address);
                        }
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase);
                    }


                    // Update details
                    // PUT /api/phonebook
                    // PhoneBookEntry phonebookentry = new PhoneBookEntry();
                    newEntry.Number = "01 6666666";
                    response = await client.PutAsJsonAsync("number/01 5555555", newEntry);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Number has been Updated");
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase + "ERRRRRRROOOR");
                    }


                    // DELETE ../api/phonebook/{number}
                    //response = await client.DeleteAsync("phonebook/number/01 1111111");
                    //if (response.IsSuccessStatusCode)
                    //{
                    //    Console.WriteLine("Record Deleted");
                    //}
                    //else
                    //{
                    //    Console.WriteLine(response.StatusCode + "   " + response.ReasonPhrase + "   DELETE ERROR");
                    //}


                    // GET.. /api/phonebook
                    response = await client.GetAsync("api/phonebook");
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsAsync<IEnumerable<PhoneBookEntry>>();
                        foreach (var i in result)
                        {
                            Console.WriteLine(i.Number + " " + i.Name + " " + i.Address);
                        }
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase);
                    }




                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            Console.ReadLine();
        }

        static void Main(string[] args)
        {
            DoWork().Wait();
        }
    }
}

                
