﻿namespace SMSApplicationCAPrep.Models
{
    public class TextMessage
    {
        public string FromNumber { get; set; }
        public string Content { get; set; }
        public string ToNumber { get; set; }
    }
}
