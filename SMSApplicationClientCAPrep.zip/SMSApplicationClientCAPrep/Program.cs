﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using SMSApplicationCAPrep.Models;

namespace SMSApplicationClientCAPrep
{
    class Client
    {
        static async Task RunAsync()
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:51042/"); // Base URL for API Controller i.e. RESTful service    // Run the API to get the local host address

                    // Add an accept header
                    client.DefaultRequestHeaders.
                        Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        // Or application/xml or application/bson

                    // POST /api/SMSApplication with a txt message serialized in request body
                    // Send a txt msg
                    TextMessage txt = new TextMessage()
                    {
                        FromNumber = "085 1111111",
                        Content = "Hello :-)",
                        ToNumber = "085 2222222"
                    };
                    HttpResponseMessage response = await client.PostAsJsonAsync("api/SMSApplication", txt);
                    if (response.IsSuccessStatusCode)
                    {
                        Console.WriteLine("Message sent ok");
                    }
                    else
                    {
                        Console.WriteLine(response.StatusCode + " " + response.ReasonPhrase);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine((e.ToString()));
            }
            Console.ReadLine();
        }

        // Kick off
        static void Main()
        {
            Task result = RunAsync();
            result.Wait();
        }
    }
}
